# Image credits

The photographs below were downloaded from Pexels under its free-use licence. Replace them with approved commissioned photography when available.

- `accra-skyline.webp` — Modern Skyline View of Accra, Ghana, Prince Enos: https://www.pexels.com/photo/modern-skyline-view-of-accra-ghana-31782030/
- `tema-port.webp` — Tema Port with Shipping Containers and Cranes in Ghana, Kweku Pozybhle Directs: https://www.pexels.com/photo/tema-port-with-shipping-containers-and-cranes-in-ghana-32458792/
- `ghana-agriculture.webp` — Ghanaian Farmer Spraying Crops in Field, RoyalArk Pictures: https://www.pexels.com/photo/ghanaian-farmer-spraying-crops-in-field-36667248/
- `accra-market.webp` — Bustling Market Scene in Accra, Ghana, Zeal Creative Studios: https://www.pexels.com/photo/bustling-market-scene-in-accra-ghana-36392318/
- `executive-discussion.webp` — Two Men Talking to Each Other About Business, PNW Production: https://www.pexels.com/photo/two-men-talking-to-each-other-about-business-8276198/
- `business-delegation.webp` — High-Level Business Meeting in Lagos Office, Ninthgrid: https://www.pexels.com/photo/high-level-business-meeting-in-lagos-office-30688592/

## Client-supplied photography

- `leadership-portrait.jpeg` — portrait supplied by the client for the leadership sections.
