import Link from "next/link";

export function ContactCTA({ title = "Begin with a clear objective", text = "Tell us what your organisation is seeking to achieve in Ghana. We will review the objective, scope and proposed timing before suggesting a responsible next step.", label = "Discuss an Assignment" }) {
  return (
    <section className="contact-cta">
      <div className="shell contact-cta-grid">
        <div><span className="eyebrow">Confidential enquiry</span><h2>{title}</h2><p>{text}</p></div>
        <Link className="button button-primary" href="/contact"><span>{label}</span><b aria-hidden="true">↗</b></Link>
      </div>
    </section>
  );
}
