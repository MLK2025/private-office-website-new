"use client";

import { FormEvent, useState } from "react";
import { services } from "../../lib/site-content";

export function EnquiryForm() {
  const [status, setStatus] = useState<"idle" | "sending" | "success" | "error">("idle");
  const [message, setMessage] = useState("");

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setStatus("sending");
    setMessage("");
    const form = event.currentTarget;
    const data = Object.fromEntries(new FormData(form).entries());

    try {
      const response = await fetch("/api/enquiry", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(data),
      });
      const result = await response.json() as { message?: string };
      if (!response.ok) throw new Error(result.message || "Unable to submit the enquiry.");
      setStatus("success");
      setMessage(result.message || "Thank you. Your enquiry has been received for review.");
      form.reset();
    } catch (error) {
      setStatus("error");
      setMessage(error instanceof Error ? error.message : "Unable to submit the enquiry. Please try again later.");
    }
  }

  return (
    <form className="enquiry-form" onSubmit={submit}>
      <div className="form-section-heading"><span>01</span><div><h2>Your details</h2><p>Fields marked with an asterisk are required.</p></div></div>
      <div className="form-grid form-grid-two">
        <label>Full name *<input name="fullName" autoComplete="name" required /></label>
        <label>Position or title *<input name="position" autoComplete="organization-title" required /></label>
        <label>Organisation *<input name="organisation" autoComplete="organization" required /></label>
        <label>Country *<input name="country" autoComplete="country-name" required /></label>
        <label>Official email *<input type="email" name="email" autoComplete="email" required /></label>
        <label>Telephone<input type="tel" name="telephone" autoComplete="tel" /></label>
        <label className="form-span-two">Organisation website *<input type="url" name="website" placeholder="https://example.com or explain below if unavailable" required /></label>
      </div>

      <div className="form-section-heading"><span>02</span><div><h2>The assignment</h2><p>Give us enough information to assess suitability and the next responsible step.</p></div></div>
      <div className="form-grid form-grid-two">
        <label>Service required *<select name="service" required defaultValue=""><option value="" disabled>Select a service</option>{services.map((service) => <option value={service.title} key={service.slug}>{service.title}</option>)}</select></label>
        <label>Preferred period<input type="text" name="preferredPeriod" placeholder="For example: January–March 2027" /></label>
        <label>Participants<input type="number" name="participants" min="1" inputMode="numeric" /></label>
        <label>How did you hear about us?<select name="referral" defaultValue=""><option value="">Select an option</option><option>Professional referral</option><option>Search engine</option><option>Event or delegation</option><option>Social media</option><option>Other</option></select></label>
        <label className="form-span-two">Purpose of enquiry *<textarea name="purpose" required minLength={40} rows={7} placeholder="Describe the organisation, objective, sector, intended timing and the type of support required." /></label>
        <label className="form-span-two honeypot" aria-hidden="true">Leave this field empty<input name="companyFax" tabIndex={-1} autoComplete="off" /></label>
      </div>

      <fieldset className="consent-group">
        <legend>Consent</legend>
        <label className="check-label"><input type="checkbox" name="privacyConsent" value="yes" required /><span>I have read the Privacy Notice and consent to the use of my information to review and respond to this enquiry. *</span></label>
        <label className="check-label"><input type="checkbox" name="marketingConsent" value="yes" /><span>I would like to receive occasional relevant updates from The Private Office.</span></label>
      </fieldset>

      <p className="form-caution">Do not submit passport copies, banking information, medical records, passwords or other highly sensitive personal information through this form.</p>
      <button className="button button-primary" type="submit" disabled={status === "sending"}>{status === "sending" ? "Submitting…" : "Submit Your Enquiry"}</button>
      {message ? <p className={`form-message ${status}`} role={status === "error" ? "alert" : "status"}>{message}</p> : null}
    </form>
  );
}
