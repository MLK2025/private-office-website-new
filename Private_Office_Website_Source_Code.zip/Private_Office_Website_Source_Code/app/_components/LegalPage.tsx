type LegalSection = { heading: string; text: string };

export function LegalPage({ eyebrow, title, intro, sections }: { eyebrow: string; title: string; intro: string; sections: LegalSection[] }) {
  return <main>
    <header className="legal-hero"><div className="shell"><span className="eyebrow">{eyebrow}</span><h1>{title}</h1><p>{intro}</p></div></header>
    <section className="section"><div className="shell legal-layout"><article className="legal-body">{sections.map((section) => <section key={section.heading}><h2>{section.heading}</h2><p>{section.text}</p></section>)}</article><aside className="legal-aside"><strong>Working legal draft</strong><p>Final legal-entity details, contact information and Ghanaian legal review are required before public launch.</p></aside></div></section>
  </main>;
}
