import Link from "next/link";

type PageHeroProps = {
  eyebrow: string;
  title: string;
  lead: string;
  image?: string;
  imageAlt?: string;
  action?: { label: string; href: string };
};

export function PageHero({ eyebrow, title, lead, image, imageAlt = "", action }: PageHeroProps) {
  return (
    <section className={`page-hero ${image ? "page-hero-with-image" : ""}`}>
      <div className="shell page-hero-grid">
        <div className="page-hero-copy">
          <span className="eyebrow">{eyebrow}</span>
          <h1>{title}</h1>
          <p>{lead}</p>
          {action ? <Link className="button button-primary" href={action.href}>{action.label}</Link> : null}
        </div>
        {image ? <figure className="page-hero-image"><img src={image} alt={imageAlt} /></figure> : null}
      </div>
    </section>
  );
}
