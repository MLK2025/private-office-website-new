import Link from "next/link";

export function SiteFooter() {
  return (
    <footer className="site-footer">
      <div className="shell">
        <aside className="footer-status" aria-label="Independent status">
          <strong><span aria-hidden="true" /> Independent status</strong>
          <p>The Private Office is an independent private organisation. We do not represent the Government of Ghana, sell access to public officials or guarantee official decisions.</p>
        </aside>
        <div className="footer-grid">
          <div className="footer-summary">
            <div className="footer-logo-crop" aria-hidden="true"><img src="/images/private-office-logo-original.png" alt="" /></div>
            <h2>The Private Office of Oseadeeyo Nana Kumi Kodie</h2>
            <p>Independent support for market entry, institutional coordination, corporate representation, delegations and commercial partnerships in Ghana.</p>
          </div>
          <nav className="footer-links" aria-label="Footer navigation">
            <strong>Explore</strong>
            <Link href="/about">About</Link><Link href="/services">Services</Link><Link href="/sectors">Sectors</Link><Link href="/delegations">Delegations</Link><Link href="/insights">Insights</Link><Link href="/contact">Contact</Link>
          </nav>
          <nav className="footer-links" aria-label="Featured services">
            <strong>Services</strong>
            <Link href="/services/ghana-market-entry">Ghana Market Entry</Link>
            <Link href="/services/corporate-representation">Corporate Representation</Link>
            <Link href="/services/business-delegations">Business Delegations</Link>
            <Link href="/services/trade-partnership-matchmaking">Trade Matchmaking</Link>
          </nav>
          <nav className="footer-links" aria-label="Legal navigation">
            <strong>Legal</strong>
            <Link href="/privacy">Privacy Notice</Link><Link href="/cookies">Cookie Notice</Link><Link href="/terms">Website Terms</Link><Link href="/disclaimer">Disclaimer</Link>
          </nav>
        </div>
        <div className="footer-bottom">
          <p>Accra, Ghana · Supporting credible international engagement.</p>
          <p>© {new Date().getFullYear()} The Private Office. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
