import Link from "next/link";

const nav = [
  ["About", "/about"],
  ["Services", "/services"],
  ["Sectors", "/sectors"],
  ["Delegations", "/delegations"],
  ["Insights", "/insights"],
  ["Contact", "/contact"],
];

export function SiteHeader() {
  return (
    <header className="site-header">
      <div className="shell header-inner">
        <Link className="brand" href="/" aria-label="The Private Office home">
          <span className="header-logo-crop" aria-hidden="true"><img src="/images/private-office-logo-original.png" alt="" /></span>
          <span className="brand-copy">
            <strong>The Private Office</strong>
            <small>Oseadeeyo Nana Kumi Kodie</small>
          </span>
        </Link>
        <nav className="desktop-nav" aria-label="Primary navigation">
          {nav.map(([label, href]) => <Link key={href} href={href}>{label}</Link>)}
        </nav>
        <Link className="button button-outline header-action" href="/contact">Discuss an Assignment <span aria-hidden="true">↗</span></Link>
        <details className="mobile-menu">
          <summary aria-label="Open navigation">Menu</summary>
          <nav aria-label="Mobile navigation">
            {nav.map(([label, href]) => <Link key={href} href={href}>{label}</Link>)}
          </nav>
        </details>
      </div>
    </header>
  );
}
