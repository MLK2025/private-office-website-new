import type { Metadata } from "next";
import Link from "next/link";
import { ContactCTA } from "../_components/ContactCTA";
import { PageHero } from "../_components/PageHero";

export const metadata: Metadata = { title: "About The Private Office", description: "Learn how The Private Office supports credible commercial and institutional engagement in Ghana." };

const principles = [
  ["Our purpose", "We support international companies, investors, associations and senior executives that require informed local coordination. Our role is to understand the objective, map the relevant environment, identify credible counterparties and organise a disciplined path from initial enquiry to practical action."],
  ["What we do", "Our work includes market-entry support, local corporate representation, business delegations, trade and partnership matchmaking, institutional partnership support, executive research, diaspora and executive coordination, and the origination of suitable projects and commercial relationships."],
  ["How we work", "Each assignment begins with a review of the client, objective, sector, intended counterparties and required professional support. Where the matter is suitable, we issue a written proposal defining the scope, outputs, responsibilities, timetable and fees. We do not approach institutions or represent clients without a clear mandate."],
  ["Independent status", "The Private Office is an independent private organisation. It is not part of the Government of Ghana, an embassy or a public authority. We do not sell access to officials, influence regulatory decisions or guarantee approvals, contracts, permits, visas or financing."],
];

export default function AboutPage() {
  return <main>
    <PageHero eyebrow="About the Office" title="An Independent Office for Credible International Engagement" lead="The Private Office of Oseadeeyo Nana Kumi Kodie was established to help serious organisations navigate relationships, opportunities and executive engagement in Ghana with greater clarity and continuity." image="/images/executive-discussion.webp" imageAlt="Two professionals discussing a business assignment" action={{ label: "Discuss an Assignment", href: "/contact" }} />
    <section className="section"><div className="shell content-grid">{principles.map(([heading, text], index) => <article className="content-block" key={heading}><span>{String(index + 1).padStart(2, "0")}</span><h2>{heading}</h2><p>{text}</p></article>)}</div></section>
    <section className="section soft-section"><div className="shell two-column-copy"><div><span className="eyebrow">Clear separation</span><h2>Relationship with Dadaba Group</h2></div><div><p>The Private Office and Dadaba Group have distinct roles. The Office may identify and coordinate a relationship or opportunity. When the required work falls within the approved field of a Dadaba Group company, that company may undertake the operational or commercial assignment under its own agreement, regulatory responsibilities and invoice. Clients are informed when another entity will be involved.</p><h3>Professional network</h3><p>Where legal, tax, immigration, accounting, property, financial or other regulated advice is required, we introduce the client to an appropriately qualified independent professional. The adviser remains responsible for the advice and professional engagement.</p></div></div></section>
    <section className="section standard-section"><div className="shell standard-grid"><div><span className="eyebrow">Our standard</span><h2>Discretion, accuracy and practical follow-through</h2><p>We value respectful institutional conduct, clear records and responsible next steps. A meeting is useful only when it serves a legitimate objective.</p></div><Link className="button button-secondary" href="/about/leadership">Meet the Chairman</Link></div></section>
    <ContactCTA />
  </main>;
}
