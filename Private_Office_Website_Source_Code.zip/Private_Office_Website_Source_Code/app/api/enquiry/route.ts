const required = ["fullName", "position", "organisation", "country", "email", "website", "service", "purpose", "privacyConsent"];

export async function POST(request: Request) {
  let payload: Record<string, unknown>;
  try { payload = await request.json() as Record<string, unknown>; }
  catch { return Response.json({ message: "The enquiry could not be read." }, { status: 400 }); }

  if (payload.companyFax) return Response.json({ message: "Thank you." });
  if (required.some((field) => typeof payload[field] !== "string" || !String(payload[field]).trim())) return Response.json({ message: "Please complete all required fields." }, { status: 400 });
  if (!/^\S+@\S+\.\S+$/.test(String(payload.email))) return Response.json({ message: "Please enter a valid email address." }, { status: 400 });
  if (String(payload.purpose).trim().length < 40) return Response.json({ message: "Please provide a little more detail about the objective." }, { status: 400 });

  const endpoint = process.env.ZOHO_ENQUIRY_WEBHOOK_URL;
  if (!endpoint) return Response.json({ message: "Online enquiry routing is being configured. Please try again later." }, { status: 503 });

  const safePayload = Object.fromEntries(Object.entries(payload).filter(([key]) => key !== "companyFax"));
  try {
    const response = await fetch(endpoint, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(safePayload) });
    if (!response.ok) throw new Error("Routing failed");
    return Response.json({ message: "Thank you. Your enquiry has been received for review. This acknowledgement does not confirm a meeting, introduction or assignment." }, { status: 202 });
  } catch {
    return Response.json({ message: "We could not route the enquiry at this time. Please try again later." }, { status: 502 });
  }
}
