import type { Metadata } from "next";
import { EnquiryForm } from "../_components/EnquiryForm";
import { PageHero } from "../_components/PageHero";

export const metadata: Metadata = { title: "Contact", description: "Submit a Ghana market-entry, representation, delegation, partnership or executive-support enquiry for review." };

export default function ContactPage() {
  return <main>
    <PageHero eyebrow="Contact and enquiry" title="Begin with a Clear Objective" lead="Tell us what your organisation is seeking to achieve in Ghana. We review each enquiry before proposing a meeting, introduction or assignment." />
    <section className="section"><div className="shell contact-layout"><div className="contact-intro"><article><span className="eyebrow">What happens next</span><h2>A considered initial review</h2><p>You will receive an automatic acknowledgement. A member of the Office will review the organisation, objective, service required and proposed timing. If the matter falls within our scope, we will request any necessary information and propose an initial discussion or written scope.</p></article><article><span className="eyebrow">Response expectation</span><h2>Within two working days</h2><p>We aim to acknowledge enquiries immediately and provide a substantive initial response within two working days. Complex or regulated matters may require additional review.</p></article><article className="contact-placeholder"><strong>Approved contact details pending</strong><p>The official email address, telephone number, office address and working hours will be added when supplied and approved.</p></article></div><EnquiryForm /></div></section>
  </main>;
}
