import type { Metadata } from "next";
import { LegalPage } from "../_components/LegalPage";

export const metadata: Metadata = { title: "Cookie Notice", description: "How this website uses essential and optional technologies." };

export default function CookiePage() { return <LegalPage eyebrow="Legal" title="Cookie Notice" intro="A concise explanation of the technologies used by this website." sections={[
  { heading: "Essential technologies", text: "This website uses essential technologies required for security, navigation and form operation. These technologies support features requested by the visitor and cannot be disabled through a consent preference." },
  { heading: "Optional analytics", text: "With your permission, the website may use analytics technologies to understand aggregate website use and improve performance. Non-essential analytics or marketing cookies remain disabled until consent is given." },
  { heading: "Your choices", text: "Where optional technologies are enabled, the cookie banner will allow visitors to accept, reject or manage non-essential cookies with equal ease. A current cookie register will identify each cookie, provider, purpose and duration." },
]} />; }
