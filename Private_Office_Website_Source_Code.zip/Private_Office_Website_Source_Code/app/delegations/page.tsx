import type { Metadata } from "next";
import Link from "next/link";
import { ContactCTA } from "../_components/ContactCTA";
import { PageHero } from "../_components/PageHero";

export const metadata: Metadata = { title: "Business Delegations and Executive Visits to Ghana", description: "Plan a focused Ghana business programme with relevant meetings, site visits, executive briefings and follow-up." };

const phases = [
  ["Before", "We hold a planning consultation, define the desired outcomes, collect participant information, research counterparties, design the programme and submit appropriate meeting requests."],
  ["During", "The approved programme may include business and institutional meetings, company visits, factory or farm visits, project and site visits, round-table discussions, executive briefings, interpreters and coordinated transport."],
  ["After", "We prepare an action summary, record agreed next steps and, where commissioned, coordinate follow-up with participating organisations."],
];

export default function DelegationsPage() {
  return <main>
    <PageHero eyebrow="Delegations" title="Plan a Purposeful Business Delegation to Ghana" lead="A well-designed delegation combines clear objectives, suitable participants, relevant meetings, practical logistics and disciplined follow-up. The Private Office coordinates each stage through one accountable programme." image="/images/business-delegation.webp" imageAlt="Business professionals taking part in a structured meeting" action={{ label: "Plan a Business Delegation", href: "/contact?service=Business%20Delegations%20and%20Executive%20Visits" }} />
    <section className="section"><div className="shell"><div className="section-intro split-heading"><div><span className="eyebrow">Suitable delegations</span><h2>Designed around legitimate objectives</h2></div><p>Suitable programmes include trade associations, chambers of commerce, corporate leadership teams, investors, professional bodies, universities, diaspora business groups and public-private missions with a lawful commercial or institutional purpose.</p></div><div className="phase-grid">{phases.map(([phase, text], index) => <article className="phase-card" key={phase}><span>0{index + 1}</span><h2>{phase} the visit</h2><p>{text}</p></article>)}</div></div></section>
    <section className="section soft-section"><div className="shell delegation-details"><article><span className="eyebrow">Lead time</span><h2>Allow time for preparation</h2><p>Submit enquiries as early as possible. Senior institutional meetings and specialised site visits require sufficient preparation and remain subject to the independent availability and approval of the host organisation.</p></article><article><span className="eyebrow">What to provide</span><h2>Information for a useful programme</h2><p>Organisation profile; delegation leader; participant number and seniority; preferred dates; sectors; target organisations; specific objectives; language needs; accessibility needs; and desired outputs.</p></article></div></section>
    <section className="section compact-section"><div className="shell legal-note"><strong>Important note</strong><p>The Private Office does not issue visas or guarantee visas, meeting confirmations or official access. Travellers remain responsible for passports, visas, insurance, health requirements and personal compliance.</p><Link className="text-link" href="/contact?service=Business%20Delegations%20and%20Executive%20Visits">Start a delegation enquiry <span aria-hidden="true">→</span></Link></div></section>
    <ContactCTA title="Plan a purposeful Ghana programme" label="Plan a Business Delegation" />
  </main>;
}
