import type { Metadata } from "next";
import { LegalPage } from "../_components/LegalPage";

export const metadata: Metadata = { title: "Website Disclaimer", description: "Important boundaries relating to The Private Office website and services." };

export default function DisclaimerPage() { return <LegalPage eyebrow="Legal" title="Website Disclaimer" intro="Important boundaries relating to the Office, third parties and potential outcomes." sections={[
  { heading: "Independent status", text: "The Private Office is an independent private organisation. It is not an office, agency or representative of the Government of Ghana or any foreign government." },
  { heading: "No implied endorsement", text: "References to institutions, companies, public bodies or professionals do not imply endorsement, partnership or authority to act for them unless expressly stated in writing." },
  { heading: "No guaranteed outcome", text: "The Office does not sell access to public officials, influence official decisions or guarantee meetings, introductions, contracts, funding, licences, permits, visas, regulatory approvals or investment outcomes." },
  { heading: "Professional advice", text: "Legal, tax, immigration, accounting, financial, property and other regulated advice is provided only by appropriately qualified professionals under their own engagements." },
]} />; }
