import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { ContactCTA } from "../../_components/ContactCTA";
import { insightArticles } from "../../../lib/site-content";

export function generateStaticParams() { return Object.keys(insightArticles).map((slug) => ({ slug })); }

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const article = insightArticles[slug];
  const description = article?.paragraphs[0]?.text;
  return article ? {
    title: article.title,
    description,
    openGraph: { title: article.title, description, images: [] },
    twitter: { card: "summary", title: article.title, description, images: [] },
  } : {};
}

export default async function InsightArticlePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const article = insightArticles[slug];
  if (!article) notFound();
  return <main>
    <article>
      <header className="article-hero"><div className="shell article-hero-inner"><span className="eyebrow">{article.category}</span><h1>{article.title}</h1><div className="article-meta"><span>The Private Office</span><span>Published {article.date}</span></div></div></header>
      <div className="shell article-layout"><div className="article-body"><p className="article-deck">This briefing supports initial preparation and discussion. It is general information, not legal, tax, investment, regulatory or technical advice.</p>{article.paragraphs.map((section) => <section key={section.heading}><h2>{section.heading}</h2><p>{section.text}</p></section>)}</div><aside className="article-aside"><strong>Responsible engagement</strong><p>Verify current requirements with the relevant Ghanaian authority and suitably qualified professional before acting.</p></aside></div>
    </article>
    <ContactCTA title="Discuss the objective behind your Ghana plans" />
  </main>;
}
