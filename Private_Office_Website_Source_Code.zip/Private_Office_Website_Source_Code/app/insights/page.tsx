import type { Metadata } from "next";
import Link from "next/link";
import { ContactCTA } from "../_components/ContactCTA";
import { PageHero } from "../_components/PageHero";
import { insights } from "../../lib/site-content";

export const metadata: Metadata = { title: "Insights", description: "Practical briefings on Ghanaian sectors, market entry, delegations and international commercial cooperation." };

export default function InsightsPage() {
  return <main>
    <PageHero eyebrow="Insights" title="Insights on Ghanaian Markets and International Cooperation" lead="Concise observations for organisations considering Ghana, preparing a visit or developing a commercial or institutional relationship. Articles distinguish practical guidance from formal professional advice." image="/images/accra-market.webp" imageAlt="Commercial activity at a market in Accra, Ghana" action={{ label: "Request an Executive Briefing", href: "/contact?service=Research%20and%20Executive%20Briefings" }} />
    <section className="section"><div className="shell insight-list">{insights.map((article) => <article className="insight-feature" key={article.slug}><div><span className="eyebrow">{article.category}</span><h2>{article.title}</h2><p>{article.summary}</p><small>Published {article.date}</small></div><Link className="button button-secondary" href={`/insights/${article.slug}`}>Read insight</Link></article>)}</div></section>
    <section className="section soft-section"><div className="shell two-column-copy"><div><span className="eyebrow">Editorial standard</span><h2>Useful, sourced and properly dated</h2></div><p>Every article names the responsible office, shows publication and update dates, avoids unsupported claims and explains material limitations. Sponsored content and partner contributions will be clearly identified.</p></div></section>
    <ContactCTA title="Need a decision-ready Ghana briefing?" label="Request an Executive Briefing" />
  </main>;
}
