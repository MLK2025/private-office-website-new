import type { Metadata } from "next";
import { SiteFooter } from "./_components/SiteFooter";
import { SiteHeader } from "./_components/SiteHeader";
import "./globals.css";

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL ?? process.env.CF_PAGES_URL ?? "https://private-office-ghana.handypixie6.chatgpt.site";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: "The Private Office | Ghana Market Entry and Executive Coordination",
    template: "%s | The Private Office",
  },
  description: "Independent support for Ghana market entry, corporate representation, business delegations, trade partnerships and executive engagement.",
  icons: { icon: "/favicon.png", shortcut: "/favicon.png" },
  openGraph: {
    type: "website",
    title: "The Private Office | Ghana Market Entry and Executive Coordination",
    description: "Independent support for Ghana market entry, corporate representation, business delegations and commercial partnerships.",
    images: [{ url: "/og.jpg", width: 1200, height: 630, alt: "The Private Office — Ghana market entry, institutional relationships and executive coordination" }],
  },
  twitter: {
    card: "summary_large_image",
    title: "The Private Office",
    description: "Independent support for credible international engagement in Ghana.",
    images: ["/og.jpg"],
  },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>
        <a className="skip-link" href="#main-content">Skip to main content</a>
        <SiteHeader />
        <div id="main-content">{children}</div>
        <SiteFooter />
      </body>
    </html>
  );
}
