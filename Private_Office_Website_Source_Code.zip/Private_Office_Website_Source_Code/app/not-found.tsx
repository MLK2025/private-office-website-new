import Link from "next/link";

export default function NotFound() { return <main className="not-found"><div className="shell"><span className="eyebrow">Page not found</span><h1>The page you requested is not available.</h1><p>Return to the home page or submit an enquiry if you need help finding the right service.</p><div className="button-row"><Link className="button button-primary" href="/">Return home</Link><Link className="button button-secondary" href="/contact">Contact the Office</Link></div></div></main>; }
