import Link from "next/link";
import { ContactCTA } from "./_components/ContactCTA";
import { insights, sectors, services } from "../lib/site-content";

const audiences = ["Foreign companies", "Investors and project sponsors", "Chambers and associations", "Embassies and trade offices", "Foundations and development organisations", "Senior executives and diaspora clients", "Ghanaian companies seeking international partners", "Professional and institutional partners"];
const reasons = [
  ["Clear preparation", "We define the assignment, research the relevant environment and identify the people or organisations that matter."],
  ["Credible coordination", "We organise communication, meetings, visits and follow-up through one accountable office."],
  ["Local perspective", "We help international clients understand Ghanaian business practice, institutional structures and practical conditions."],
  ["Continuity", "We maintain momentum after the first discussion and provide agreed activity reporting."],
];
const process = [
  ["Submit the objective", "Tell us what your organisation is seeking to achieve in Ghana."],
  ["Initial review", "We assess the objective, scope, timing, counterparties and any regulated matters."],
  ["Written proposal", "Suitable assignments receive a defined scope, deliverables, timetable and professional fee."],
  ["Coordinated delivery", "Work begins after written appointment, due diligence and the agreed initial payment."],
];

export default function Home() {
  return (
    <main>
      <section className="hero hero-kinetic">
        <div className="hero-backdrop" aria-hidden="true"><img src="/images/accra-skyline.webp" alt="" /></div>
        <div className="hero-color-wash" aria-hidden="true" />
        <div className="hero-weave" aria-hidden="true" />
        <div className="shell hero-grid">
          <div className="hero-copy">
            <div className="hero-kicker"><span className="eyebrow">Ghana to the world</span><span>Accra · Ghana</span></div>
            <h1>Institutional relationships, <em>market entry</em> and executive coordination in Ghana.</h1>
            <p className="hero-lead">The Private Office supports international companies, investors, associations and senior executives seeking credible relationships, commercial opportunities and coordinated engagement in Ghana and selected African markets.</p>
            <div className="button-row"><Link className="button button-primary" href="/contact">Discuss an Assignment</Link><Link className="button button-secondary" href="/delegations">Plan a Delegation</Link></div>
            <div className="hero-trust" aria-label="Working principles"><span>Ghana-based insight</span><span>Written mandates</span><span>Discreet coordination</span></div>
          </div>
          <aside className="hero-marker" aria-label="Location and approach">
            <div className="hero-motif" aria-hidden="true"><span /><i /><div className="hero-crest-crop"><img src="/images/private-office-logo-original.png" alt="" /></div></div>
            <span className="hero-marker-label">West Africa</span>
            <h2>Accra<br />Ghana</h2>
            <p>Local understanding.<br />International perspective.</p>
            <small>05° 33′ N · 00° 12′ W</small>
          </aside>
        </div>
        <div className="hero-ribbon" aria-label="Market entry, institutional relationships, executive coordination, business delegations">
          <div className="hero-ribbon-track" aria-hidden="true"><span>Market Entry</span><span>Institutional Relationships</span><span>Executive Coordination</span><span>Business Delegations</span><span>Market Entry</span><span>Institutional Relationships</span><span>Executive Coordination</span><span>Business Delegations</span></div>
        </div>
      </section>

      <section className="section" aria-labelledby="services-heading"><div className="shell">
        <div className="section-intro split-heading"><div><span className="eyebrow">Principal services</span><h2 id="services-heading">A disciplined point of coordination</h2></div><p>Serious international engagement requires accurate local understanding, the right counterparts, careful preparation and consistent follow-through.</p></div>
        <div className="service-grid">{services.slice(0, 4).map((service, index) => <article className={`service-card ${index === 0 ? "service-card-featured" : ""}`} key={service.slug}><div className="service-card-image"><img src={service.image} alt="" /></div><div className="service-card-content"><span className="service-number">{service.number}</span><h3>{service.shortTitle}</h3><p>{service.summary}</p><Link href={`/services/${service.slug}`}>Explore service <span aria-hidden="true">↗</span></Link></div></article>)}</div>
        <div className="section-action"><Link className="text-link" href="/services">View all eight services <span aria-hidden="true">→</span></Link></div>
      </div></section>

      <section className="section audience-section"><div className="shell audience-grid"><div><span className="eyebrow">Who we support</span><h2>Built for serious organisations and executives</h2><p>Every assignment begins with a clear purpose, responsible preparation and an appropriate mandate.</p></div><div className="audience-list">{audiences.map((audience) => <div className="audience-item" key={audience}>{audience}</div>)}</div></div></section>

      <section className="section reasons-section"><div className="shell"><div className="section-intro"><span className="eyebrow">Why appoint us</span><h2>Clarity from first enquiry to follow-through</h2></div><div className="reason-grid">{reasons.map(([title, text], index) => <article className="reason" key={title}><span className="reason-index">0{index + 1}</span><h3>{title}</h3><p>{text}</p></article>)}</div></div></section>

      <section className="sector-process-split">
        <div className="sector-panel"><div className="panel-inner"><span className="eyebrow">Selected sectors</span><h2>Opportunity areas</h2><div className="sector-compact-list">{sectors.map(([name]) => <span key={name}>{name}</span>)}</div><Link className="light-link" href="/sectors">Explore all sectors <span aria-hidden="true">→</span></Link></div></div>
        <div className="process-panel"><div className="panel-inner"><span className="eyebrow">How an engagement begins</span><h2>Four clear steps</h2><div className="steps">{process.map(([title, text], index) => <div className="step" key={title}><span>{index + 1}</span><div><h3>{title}</h3><p>{text}</p></div></div>)}</div></div></div>
      </section>

      <section className="section leadership-teaser"><div className="shell leadership-grid"><figure className="leadership-photo"><img className="leadership-portrait" src="/images/leadership-portrait.jpeg" alt="Portrait of Dr Oseadeeyo Nana Kumi Kodie seated in his office" /><figcaption><strong>Dr Oseadeeyo Nana Kumi Kodie</strong><span>Chairman &amp; Group Chief Executive</span></figcaption></figure><div><span className="eyebrow">Leadership</span><h2>Grounded in Ghana and oriented towards international cooperation</h2><p>The Private Office is chaired by Dr Oseadeeyo Nana Kumi Kodie, a Ghanaian traditional leader and Group Chief Executive of Dadaba Group Companies Ltd. His work brings together enterprise, relationship-building and a long-term commitment to trade, investment and development cooperation.</p><Link className="text-link" href="/about/leadership">Read the Chairman’s profile <span aria-hidden="true">→</span></Link></div></div></section>

      <section className="section insights-section"><div className="shell"><div className="section-intro split-heading"><div><span className="eyebrow">Insights</span><h2>Practical briefings for engagement in Ghana</h2></div><p>Concise observations for organisations considering Ghana, preparing a visit or developing a commercial or institutional relationship.</p></div><div className="insight-grid">{insights.map((article) => <article className="insight-card" key={article.slug}><span>{article.category}</span><h3>{article.title}</h3><p>{article.summary}</p><Link href={`/insights/${article.slug}`}>Read insight <span aria-hidden="true">→</span></Link></article>)}</div></div></section>

      <ContactCTA />
    </main>
  );
}
