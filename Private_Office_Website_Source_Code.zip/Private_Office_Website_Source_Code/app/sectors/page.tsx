import type { Metadata } from "next";
import { ContactCTA } from "../_components/ContactCTA";
import { PageHero } from "../_components/PageHero";
import { sectors } from "../../lib/site-content";

export const metadata: Metadata = { title: "Sectors and Opportunities", description: "Explore sectors where The Private Office can coordinate serious commercial and institutional engagement in Ghana." };

export default function SectorsPage() {
  return <main>
    <PageHero eyebrow="Sectors and opportunities" title="Sectors Where We Can Coordinate Serious Engagement" lead="Our role is to help clients understand the landscape, identify credible participants and organise the early stages of an assignment. Sector-specific technical, legal, financial and regulatory work is undertaken by the relevant qualified adviser or operating company." image="/images/ghana-agriculture.webp" imageAlt="Agricultural activity in Ghana" action={{ label: "Discuss a Sector Assignment", href: "/contact" }} />
    <section className="section"><div className="shell sector-grid">{sectors.map(([name, description], index) => <article className="sector-card" key={name}><span>{String(index + 1).padStart(2, "0")}</span><h2>{name}</h2><p>{description}</p></article>)}</div></section>
    <section className="section soft-section"><div className="shell two-column-copy"><div><span className="eyebrow">Opportunity standard</span><h2>Suitable objectives and credible information</h2></div><p>We accept opportunities only when the objective is lawful, the proposed parties can be identified, the information supplied is credible and appropriate professional support can be arranged.</p></div></section>
    <ContactCTA />
  </main>;
}
