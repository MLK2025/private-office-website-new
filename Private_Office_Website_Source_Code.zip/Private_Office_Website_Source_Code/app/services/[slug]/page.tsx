import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { ContactCTA } from "../../_components/ContactCTA";
import { PageHero } from "../../_components/PageHero";
import { services } from "../../../lib/site-content";

export function generateStaticParams() { return services.map(({ slug }) => ({ slug })); }

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const service = services.find((item) => item.slug === slug);
  return service ? {
    title: service.title,
    description: service.summary,
    openGraph: { title: service.title, description: service.summary, images: [{ url: service.image, alt: service.imageAlt }] },
    twitter: { card: "summary_large_image", title: service.title, description: service.summary, images: [service.image] },
  } : {};
}

export default async function ServicePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const service = services.find((item) => item.slug === slug);
  if (!service) notFound();
  return <main>
    <PageHero eyebrow={`Service ${service.number}`} title={service.title} lead={service.summary} image={service.image} imageAlt={service.imageAlt} action={{ label: service.cta, href: `/contact?service=${encodeURIComponent(service.title)}` }} />
    <section className="section"><div className="shell service-detail-grid">{service.sections.map((section, index) => <article className={section.heading.toLowerCase().includes("boundary") || section.heading.toLowerCase().includes("guarantee") || section.heading === "Independence" || section.heading === "Privacy" ? "service-detail boundary" : "service-detail"} key={section.heading}><span>{String(index + 1).padStart(2, "0")}</span><div><h2>{section.heading}</h2><p>{section.text}</p></div></article>)}</div></section>
    <ContactCTA title={service.cta} label={service.cta} />
  </main>;
}
