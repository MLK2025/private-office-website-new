import type { Metadata } from "next";
import Link from "next/link";
import { ContactCTA } from "../_components/ContactCTA";
import { PageHero } from "../_components/PageHero";
import { services } from "../../lib/site-content";

export const metadata: Metadata = { title: "Services", description: "Practical support for Ghana market entry, representation, delegations, partnerships, research and executive engagement." };

export default function ServicesPage() {
  return <main>
    <PageHero eyebrow="Services" title="Practical Support for International Engagement in Ghana" lead="The Private Office provides defined assignments for organisations that need local understanding, credible coordination and consistent follow-through. Services may be commissioned separately or combined within a single engagement." image="/images/tema-port.webp" imageAlt="Tema Port in Ghana with shipping containers and cranes" action={{ label: "Submit a Service Enquiry", href: "/contact" }} />
    <section className="section"><div className="shell services-list">{services.map((service) => <article className="service-row" key={service.slug}><span className="service-number">{service.number}</span><div><h2>{service.title}</h2><p>{service.summary}</p></div><Link className="text-link" href={`/services/${service.slug}`}>View service <span aria-hidden="true">→</span></Link></article>)}</div></section>
    <section className="section soft-section"><div className="shell two-column-copy"><div><span className="eyebrow">Engagement basis</span><h2>Defined scope and responsible boundaries</h2></div><p>All assignments are subject to review, written scope, appropriate due diligence and agreed fees. Regulated advice and operational services are provided by the responsible qualified professional or operating company.</p></div></section>
    <ContactCTA />
  </main>;
}
