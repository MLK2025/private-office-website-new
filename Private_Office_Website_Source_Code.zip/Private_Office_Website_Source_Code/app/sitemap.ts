import type { MetadataRoute } from "next";
import { insights, services } from "../lib/site-content";

export default function sitemap(): MetadataRoute.Sitemap {
  const base = process.env.NEXT_PUBLIC_SITE_URL || "https://privateofficeofdon.com";
  const pages = ["", "/about", "/about/leadership", "/services", "/sectors", "/delegations", "/insights", "/contact", "/privacy", "/cookies", "/terms", "/disclaimer"];
  return [
    ...pages.map((path) => ({ url: `${base}${path}`, lastModified: new Date(), changeFrequency: path === "/insights" ? "weekly" as const : "monthly" as const, priority: path === "" ? 1 : .7 })),
    ...services.map(({ slug }) => ({ url: `${base}/services/${slug}`, lastModified: new Date(), changeFrequency: "monthly" as const, priority: .8 })),
    ...insights.map(({ slug }) => ({ url: `${base}/insights/${slug}`, lastModified: new Date(), changeFrequency: "monthly" as const, priority: .6 })),
  ];
}
