import type { Metadata } from "next";
import { LegalPage } from "../_components/LegalPage";

export const metadata: Metadata = { title: "Website Terms", description: "Terms governing use of The Private Office website." };

export default function TermsPage() { return <LegalPage eyebrow="Legal" title="Website Terms" intro="These working terms describe the basis on which this website may be used." sections={[
  { heading: "Lawful use", text: "By using this website, you agree to use it lawfully and not to interfere with its security, submit false information, impersonate another person, upload malicious material or misuse the Office’s name, content or contact channels." },
  { heading: "No engagement created", text: "Website content is general information and does not create a client, agency, advisory or fiduciary relationship. An assignment begins only under a written agreement accepted by the responsible parties." },
  { heading: "Content and external links", text: "Unless otherwise stated, website text, design and original materials belong to the responsible legal entity and may not be reproduced commercially without permission. External links are provided for convenience and do not constitute endorsement." },
  { heading: "Liability and governing law", text: "To the extent permitted by law, the Office is not responsible for loss arising solely from reliance on general website information. These terms are governed by the laws of Ghana, subject to any mandatory rights that apply." },
]} />; }
