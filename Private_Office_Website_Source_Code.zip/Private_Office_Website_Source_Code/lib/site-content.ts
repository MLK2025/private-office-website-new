export type ServiceSection = {
  heading: string;
  text: string;
};

export type Service = {
  slug: string;
  number: string;
  title: string;
  shortTitle: string;
  summary: string;
  image: string;
  imageAlt: string;
  sections: ServiceSection[];
  cta: string;
};

export const services: Service[] = [
  {
    slug: "ghana-market-entry",
    number: "01",
    title: "Ghana Market Entry Support",
    shortTitle: "Ghana Market Entry",
    summary: "A disciplined first step for organisations considering Ghana.",
    image: "/images/accra-skyline.webp",
    imageAlt: "Modern commercial buildings in Accra, Ghana",
    sections: [
      { heading: "Who this is for", text: "Foreign companies, investors, associations and professional firms that need a practical understanding of Ghana before committing resources or appointing local partners." },
      { heading: "The problem it solves", text: "Early market-entry decisions can be weakened by fragmented information, unsuitable introductions and a poor understanding of local structures. We organise the first stage around verified information, defined priorities and credible counterparties." },
      { heading: "What the service may include", text: "Preliminary market and sector briefings; stakeholder and regulatory mapping; competitor and channel observations; local partner or distributor identification; meeting coordination; introductions to qualified advisers; site and project visits; visit briefs; and agreed follow-up." },
      { heading: "What the client receives", text: "A written scope, target map, research findings, proposed engagement plan, meeting programme where approved, contact records and a final action summary." },
      { heading: "How the assignment begins", text: "Submit the target sector, intended product or service, preferred entry model, decision timetable and the type of Ghanaian counterpart required. We review suitability and provide a scoped proposal." },
      { heading: "Important boundary", text: "The service supports commercial preparation and coordination. It does not replace legal, tax, regulatory, financial or technical advice, and it does not guarantee market entry or official approval." },
    ],
    cta: "Discuss Your Ghana Market Entry",
  },
  {
    slug: "corporate-representation",
    number: "02",
    title: "Corporate Representation in Ghana",
    shortTitle: "Corporate Representation",
    summary: "A reliable local point of coordination for approved commercial activity.",
    image: "/images/executive-discussion.webp",
    imageAlt: "Business professionals reviewing an assignment together",
    sections: [
      { heading: "Who this is for", text: "International companies and organisations that require a continuing Ghanaian presence before establishing a full local office or appointing a permanent team." },
      { heading: "The problem it solves", text: "Distance can slow communication, weaken follow-up and leave opportunities without a responsible local owner. We provide agreed representation within a clear mandate." },
      { heading: "What the service may include", text: "Local correspondence; meeting arrangements; opportunity monitoring; stakeholder and partner follow-up; preparation of local activity notes; coordination with appointed advisers; executive-visit support; and periodic written reports." },
      { heading: "Mandate and limits", text: "The representation agreement states what we may communicate, arrange and report. We do not sign contracts, make binding commitments, collect funds, provide regulated advice or act outside written authority." },
      { heading: "Reporting", text: "Clients receive an agreed schedule of activity reports recording communications, meetings, decisions required, open matters and recommended next actions." },
      { heading: "How the assignment begins", text: "Provide the organisation’s profile, Ghana objective, intended stakeholders, expected duration and authority required. Following due diligence, we propose a retainer or defined project mandate." },
    ],
    cta: "Request Corporate Representation",
  },
  {
    slug: "business-delegations",
    number: "03",
    title: "Business Delegations and Executive Visits",
    shortTitle: "Business Delegations",
    summary: "Purposeful Ghana programmes designed around business objectives, not ceremonial activity.",
    image: "/images/business-delegation.webp",
    imageAlt: "Business professionals in a structured meeting",
    sections: [
      { heading: "Who this is for", text: "Companies, chambers, associations, investors, project teams, universities and senior executives planning a structured visit to Ghana." },
      { heading: "The problem it solves", text: "A valuable visit requires the right meetings, realistic travel time, reliable logistics, careful briefing and disciplined follow-up. We combine these elements within one programme." },
      { heading: "What the service may include", text: "Pre-visit consultation; objective setting; participant information; programme and itinerary design; business and institutional meeting requests; company, factory, farm and project visits; executive briefings; airport reception coordination; hotels, transport and interpreters through approved suppliers; meeting materials; and post-visit follow-up." },
      { heading: "Programme approval", text: "Proposed meetings remain subject to the availability and independent agreement of each organisation. No meeting with a public official, company or institution is represented as confirmed until written confirmation has been received." },
      { heading: "How the assignment begins", text: "Submit the delegation objective, preferred dates, number and seniority of participants, sectors of interest and desired outcomes. Allow adequate lead time for research and meeting requests." },
      { heading: "After the visit", text: "We issue an action summary and, where commissioned, coordinate approved correspondence and next steps." },
    ],
    cta: "Plan a Business Delegation",
  },
  {
    slug: "trade-partnership-matchmaking",
    number: "04",
    title: "Trade and Partnership Matchmaking",
    shortTitle: "Trade and Partnership Matchmaking",
    summary: "Structured connections between credible organisations with a defined commercial purpose.",
    image: "/images/tema-port.webp",
    imageAlt: "Shipping containers and cranes at Tema Port in Ghana",
    sections: [
      { heading: "Who this is for", text: "Foreign buyers, Ghanaian suppliers, manufacturers, distributors, investors, project sponsors, associations and companies seeking capable international or local partners." },
      { heading: "The problem it solves", text: "A contact list is not a partnership. We begin with criteria, examine potential fit and coordinate a responsible first discussion." },
      { heading: "What the service may include", text: "Partner criteria; market and company research; longlisting; initial qualification; conflict and reputation checks using lawful sources; meeting coordination; briefing notes; exchange of approved information; and follow-up." },
      { heading: "Qualification principles", text: "Potential counterparties are assessed against the agreed purpose, apparent capacity, location, sector relevance and available public information. Full legal, financial, technical and regulatory due diligence remains the responsibility of qualified advisers and the contracting parties." },
      { heading: "How the assignment begins", text: "Submit the product, opportunity or partnership sought; target geography; capacity requirements; commercial model; timetable; and essential qualification criteria." },
      { heading: "No success guarantee", text: "We do not guarantee that an introduction will result in a contract, investment, distributorship or official support." },
    ],
    cta: "Submit a Partnership Enquiry",
  },
  {
    slug: "institutional-partnerships",
    number: "05",
    title: "Institutional Partnership Services",
    shortTitle: "Institutional Partnerships",
    summary: "Careful preparation and coordination for legitimate institutional cooperation.",
    image: "/images/business-delegation.webp",
    imageAlt: "A professional meeting focused on institutional cooperation",
    sections: [
      { heading: "Who this is for", text: "Associations, foundations, universities, traditional institutions, municipalities, development organisations and companies seeking an appropriate Ghanaian institutional relationship." },
      { heading: "The problem it solves", text: "Institutional approaches often fail when the purpose is vague, the wrong department is contacted or the proposal offers no practical value. We help define and route a credible proposition." },
      { heading: "What the service may include", text: "Institutional mapping; contact and mandate research; concept notes; meeting requests; agenda and briefing preparation; coordination of visits; minutes; action tracking; and support towards a suitable cooperation document." },
      { heading: "Appropriate instruments", text: "Depending on the relationship, the proper outcome may be an exchange of letters, referral arrangement, collaboration memorandum, supplier agreement or project-specific contract. An MOU is not required for every relationship." },
      { heading: "How the assignment begins", text: "Provide the intended institution, cooperation objective, proposed contribution, expected public benefit, timetable and any existing relationship." },
      { heading: "Independence", text: "The Office cannot commit an institution, public authority or third party. All decisions remain with the relevant organisation and authorised officeholders." },
    ],
    cta: "Discuss an Institutional Partnership",
  },
  {
    slug: "research-executive-briefings",
    number: "06",
    title: "Research and Executive Briefings",
    shortTitle: "Executive Briefings",
    summary: "Concise evidence for executives preparing to enter, visit or decide.",
    image: "/images/accra-skyline.webp",
    imageAlt: "The Accra business district seen from above",
    sections: [
      { heading: "Who this is for", text: "Executives, boards, investors, professional advisers, associations and delegation leaders requiring a focused Ghanaian briefing." },
      { heading: "The problem it solves", text: "Senior decisions are often delayed by excessive, inconsistent or poorly sourced information. We organise relevant findings into a clear decision document." },
      { heading: "What the service may include", text: "Sector overview; institutional and stakeholder map; market-entry considerations; commercial landscape; identified opportunities; public-source risk indicators; potential counterparties; interview coordination; and an executive briefing session." },
      { heading: "Research standard", text: "Sources, assumptions and verification dates are stated. Where reliable information is unavailable, the report records the limitation instead of presenting an unsupported conclusion." },
      { heading: "How the assignment begins", text: "Submit the decision to be supported, intended reader, questions to answer, sector, geography, deadline and required depth." },
      { heading: "Use of reports", text: "Reports are prepared for the commissioning client and should not be treated as legal, tax, investment or regulatory advice unless the relevant qualified professional has expressly provided that advice." },
    ],
    cta: "Request an Executive Briefing",
  },
  {
    slug: "diaspora-executive-support",
    number: "07",
    title: "Diaspora and International Executive Support",
    shortTitle: "Diaspora and Executive Support",
    summary: "Coordinated local support for serious business, investment and relocation visits.",
    image: "/images/accra-market.webp",
    imageAlt: "Commercial activity at a market in Accra, Ghana",
    sections: [
      { heading: "Who this is for", text: "Diaspora professionals, international executives and families arranging a Ghanaian business, investment, property or relocation programme." },
      { heading: "The problem it solves", text: "Clients may need several appointments and service providers but lack a trusted point of coordination. We organise the programme and appropriate professional referrals." },
      { heading: "What the service may include", text: "Business appointments; investment and site visits; property-viewing schedules with licensed professionals; transport and accommodation coordination; local orientation; administrative appointment support; and introductions to qualified lawyers, accountants, immigration practitioners, banks, insurers and property professionals." },
      { heading: "Professional advice", text: "The Private Office coordinates. Each regulated professional provides independent advice under a separate engagement and remains responsible for that advice." },
      { heading: "How the assignment begins", text: "Submit the purpose of the visit, preferred period, participants, required appointments, location and any professional services needed." },
      { heading: "Privacy", text: "Only information necessary to coordinate the approved assignment should be collected. Sensitive personal documents should be transferred through an agreed secure channel, not ordinary website forms." },
    ],
    cta: "Request Executive Support",
  },
  {
    slug: "project-partnership-origination",
    number: "08",
    title: "Project and Partnership Origination",
    shortTitle: "Project and Partnership Origination",
    summary: "Early-stage coordination for credible projects and commercial opportunities.",
    image: "/images/ghana-agriculture.webp",
    imageAlt: "A farmer working in a field in Ghana",
    sections: [
      { heading: "Who this is for", text: "Project sponsors, investors, technical companies, landowners, operating businesses and Dadaba Group companies considering suitable opportunities." },
      { heading: "The problem it solves", text: "Promising ideas often lack a clear sponsor, verified information, capable partners or an agreed route to development. We help organise the early relationship and information flow." },
      { heading: "What the service may include", text: "Initial opportunity screening; sponsor and stakeholder identification; preliminary information memorandum; partner and investor research; meeting coordination; early action plan; and referral to qualified legal, financial, environmental and technical advisers." },
      { heading: "Screening criteria", text: "We consider the sponsor, ownership, approvals, commercial logic, information quality, capital requirement, environmental and social context, delivery capacity and potential conflicts." },
      { heading: "Relationship with Dadaba Group", text: "Where appropriate, an opportunity may be referred to the relevant Dadaba Group company. Any further participation is subject to a separate decision, due diligence, agreement and regulatory responsibility." },
      { heading: "How the assignment begins", text: "Submit a concise project summary, sponsor details, location, current stage, ownership or control evidence, approvals status, capital requirement and the partnership sought." },
    ],
    cta: "Submit a Project Enquiry",
  },
];

export const sectors = [
  ["Agriculture and commodities", "Producer and buyer relationships, processing opportunities, storage, logistics, equipment, market visits and commercial introductions."],
  ["Property and infrastructure", "Project introductions, site programmes, professional referrals, stakeholder mapping and early project coordination."],
  ["Energy and utilities", "Market briefings, local partner research, institutional mapping and project-development introductions, subject to regulatory requirements."],
  ["Tourism and hospitality", "Hotel and destination investment, supplier relationships, visitor programmes and hospitality partnerships."],
  ["Healthcare and pharmaceuticals", "Market-entry research, distributor and institutional mapping, local meeting coordination and referrals to regulatory specialists."],
  ["Logistics and cold chain", "Commercial partnerships, warehousing, transport, ports, distribution and supply-chain opportunities."],
  ["Manufacturing", "Site and market visits, local supplier or distributor research, industrial-zone engagement and investment coordination."],
  ["Professional services", "Cross-border relationships among law, accounting, research, corporate-service, relocation and advisory firms."],
  ["Employment and human capital", "Institutional and employer partnerships undertaken through the appropriately licensed recruitment or operating entity."],
] as const;

export const insights = [
  {
    slug: "entering-ghana-ten-questions",
    category: "Market entry",
    title: "Entering Ghana: Ten questions to answer before approaching local partners",
    summary: "A preparation checklist for companies moving from general interest to a credible Ghana entry plan.",
    date: "20 October 2026",
  },
  {
    slug: "planning-a-ghana-business-delegation",
    category: "Delegations",
    title: "Planning a Ghana business delegation around clear outcomes",
    summary: "How to define objectives, select participants, structure meetings and allow enough preparation time.",
    date: "20 October 2026",
  },
  {
    slug: "from-introduction-to-partnership",
    category: "Partnerships",
    title: "From introduction to partnership: Why qualification and follow-through matter",
    summary: "A practical framework for moving beyond contact lists towards responsible commercial engagement.",
    date: "20 October 2026",
  },
];

export const insightArticles: Record<string, { title: string; category: string; date: string; paragraphs: Array<{ heading: string; text: string }> }> = {
  "entering-ghana-ten-questions": {
    title: insights[0].title,
    category: insights[0].category,
    date: insights[0].date,
    paragraphs: [
      { heading: "1. What decision are you preparing to make?", text: "Define the decision, its owner and its deadline. A market visit, distributor search, incorporation study and investment decision require different evidence and counterparties." },
      { heading: "2. Who is the intended customer?", text: "Describe the customer, buyer or user in practical terms. Avoid treating an entire country or sector as a single market." },
      { heading: "3. What must be verified locally?", text: "Separate assumptions from facts that require Ghana-specific confirmation, including licensing, product requirements, routes to market, pricing and the role of professional advisers." },
      { heading: "4. Which entry model is being considered?", text: "Clarify whether the organisation is exploring export, distribution, representation, a local entity, a joint venture or a project-specific partnership." },
      { heading: "5. What authority will a local representative hold?", text: "Define what a representative may communicate, arrange and report. Contract signing, regulated advice and financial authority require separate written consideration." },
      { heading: "6. What makes a potential partner suitable?", text: "Set criteria for capability, sector relevance, geography, governance, reputation and practical capacity before names are proposed." },
      { heading: "7. What due diligence is required?", text: "Plan commercial, legal, financial, technical and regulatory checks with qualified advisers. An introduction is not a substitute for due diligence." },
      { heading: "8. Which meetings would change the decision?", text: "Prioritise meetings that answer defined questions or advance a legitimate objective. Seniority alone does not make a meeting useful." },
      { heading: "9. What resources and timing are realistic?", text: "Allocate time for research, meeting requests, internal approvals and follow-up. Compressed schedules can reduce both access and decision quality." },
      { heading: "10. What happens after the first visit?", text: "Assign ownership for correspondence, verification, proposal review and next actions before the visit takes place." },
    ],
  },
  "planning-a-ghana-business-delegation": {
    title: insights[1].title,
    category: insights[1].category,
    date: insights[1].date,
    paragraphs: [
      { heading: "Start with outcomes", text: "A useful programme begins with the decisions, relationships or evidence the delegation needs. Objectives should be specific enough to guide research and meeting requests." },
      { heading: "Choose participants deliberately", text: "The size, seniority and expertise of the group should match the programme. Each participant should have a clear role in the discussions and follow-up." },
      { heading: "Allow sufficient lead time", text: "Organisations need time to review meeting requests, nominate representatives and confirm availability. Site visits and senior institutional meetings usually require additional preparation." },
      { heading: "Build a realistic programme", text: "Accra travel time, security procedures, briefing needs and the distance to factories, farms or projects should shape the itinerary. Fewer relevant meetings are often more valuable than an overloaded schedule." },
      { heading: "Prepare both sides", text: "Participants and hosts should receive an accurate purpose, agenda and organisation profile. Sensitive information should be exchanged only through approved channels." },
      { heading: "Plan the follow-through", text: "Record decisions, owners and deadlines. A concise action summary issued soon after the visit helps turn a programme into responsible progress." },
    ],
  },
  "from-introduction-to-partnership": {
    title: insights[2].title,
    category: insights[2].category,
    date: insights[2].date,
    paragraphs: [
      { heading: "Define the partnership sought", text: "State the product, opportunity, geography, capacity requirement, commercial model and timetable. Clear criteria make research and qualification more useful." },
      { heading: "Research before approaching", text: "Confirm basic relevance and apparent capacity using lawful sources. Avoid sending broad proposals to organisations whose mandate or business model does not fit." },
      { heading: "Qualify the first conversation", text: "An introductory meeting should test mutual relevance, decision authority, resources and the next evidence required. It should not be presented as a completed partnership." },
      { heading: "Separate coordination from due diligence", text: "Local coordination can organise information and discussions. Legal, financial, technical and regulatory due diligence remains with qualified advisers and the contracting parties." },
      { heading: "Document the next step", text: "Record what was agreed, who owns each action and when the parties will review progress. If there is no responsible next step, there is not yet a working partnership." },
    ],
  },
};
