import assert from "node:assert/strict";
import { access, readFile } from "node:fs/promises";
import test from "node:test";

const projectRoot = new URL("../", import.meta.url);

async function render(path = "/") {
  const workerUrl = new URL("../dist/server/index.js", import.meta.url);
  workerUrl.searchParams.set("test", `${process.pid}-${Date.now()}-${path}`);
  const { default: worker } = await import(workerUrl.href);

  return worker.fetch(
    new Request(`http://localhost${path}`, { headers: { accept: "text/html" } }),
    { ASSETS: { fetch: async () => new Response("Not found", { status: 404 }) } },
    { waitUntil() {}, passThroughOnException() {} },
  );
}

test("server-renders the finished Private Office homepage", async () => {
  const response = await render();
  assert.equal(response.status, 200);
  assert.match(response.headers.get("content-type") ?? "", /^text\/html\b/i);

  const html = await response.text();
  assert.match(html, /<title>The Private Office \| Ghana Market Entry and Executive Coordination<\/title>/i);
  assert.match(html, /Institutional relationships/);
  assert.match(html, /Discuss an Assignment/);
  assert.match(html, /Ghana-based insight/);
  assert.match(html, /We do not represent the Government of Ghana/);
  assert.match(html, /accra-skyline\.webp/);
  assert.match(html, /leadership-portrait\.jpeg/);
  assert.doesNotMatch(html, /africa-gold-accent|hero-map-layer/);
  assert.match(html, /Skip to main content/);
  assert.doesNotMatch(html, /codex-preview|SkeletonPreview|Your site is taking shape/i);
});

test("renders the supplied leadership portrait on the Chairman profile", async () => {
  const response = await render("/about/leadership");
  assert.equal(response.status, 200);
  const html = await response.text();
  assert.match(html, /leadership-portrait\.jpeg/);
  assert.match(html, /Chairman &amp; Group Chief Executive/);
  assert.doesNotMatch(html, /portrait pending|portrait and publication permission required/i);
});

test("renders representative interior content and has no starter preview", async () => {
  const response = await render("/services/ghana-market-entry");
  assert.equal(response.status, 200);
  const html = await response.text();
  assert.match(html, /Ghana Market Entry Support/);
  assert.match(html, /Who this is for/);
  assert.match(html, /Important boundary/);

  const layout = await readFile(new URL("../app/layout.tsx", import.meta.url), "utf8");
  assert.match(layout, /The Private Office/);
  assert.doesNotMatch(layout, /codex-preview|Starter Project/i);
  await assert.rejects(access(new URL("../app/_sites-preview", projectRoot)));
});
